# @dewee/identity

Server SDK of Dewee Connect: sign your users in to a Dewee agent, answer the hosted-link handoff,
report user lifecycle changes, and read the verified user inside your MCP server.

- Server only. Every entry point refuses to run where `window` exists: it holds your application
  secrets.
- Node 20.3 or later, ESM. One dependency: [`jose`](https://github.com/panva/jose). Signing and
  verification use WebCrypto, so the token format also works in Workers-style runtimes.
- Secrets, tokens and assertions never appear in an error message or in `JSON.stringify(error)`.

Status: beta (`0.x`). The contract follows the gateway's
[OpenAPI spec](https://github.com/nextlevelbuilder/dewee/blob/dev/internal/http/openapi_spec.json) (tag `Identity`); a test fails when the two
drift apart.

Not published to npm yet. Until it is, build and pack it from this repository, then install the
tarball in your app; once published, use `npm install @dewee/identity` instead.

```sh
pnpm install && pnpm --filter @dewee/identity build
cd packages/dewee-identity && pnpm pack       # writes dewee-identity-<version>.tgz
npm install /path/to/dewee-identity-<version>.tgz   # in your app
```

The full walkthrough, with curl equivalents for other languages, is the
[Dewee Connect integration recipe](https://github.com/nextlevelbuilder/dewee/blob/dev/docs/dewee-connect-integration.md). A runnable app is in
[`examples/identity-partner-sample`](https://github.com/nextlevelbuilder/dewee/blob/dev/examples/identity-partner-sample/README.md).

## API

| Function | Call |
|----------|------|
| `exchangeSession({gatewayUrl, signer, subject, agent, ttlSeconds?})` | `POST /v1/identity/sessions/exchange`. Returns `{sessionToken, header, sessionId, principalId, applicationId, agentId, expiresAt, testMode, testModeBanner?}`. Also accepts a ready `assertion` instead of `signer` and `subject`. |
| `startLink({gatewayUrl, sessionToken, idempotencyKey?})` | `POST /v1/identity/links` (web-first). Returns the proof code and the chat accounts it can be sent to. |
| `readConnectRequest(url, {connectBaseUrl})` | Reads and checks `dewee_txn` and `return_to` on your `connect_start_url`. |
| `createConnectRedirect({signer, subject, connectBaseUrl, deweeTxn, returnTo, cspNonce?})` | Signs the handoff assertion and returns the auto-submitting POST form (`html`). A strict CSP blocks the inline submit unless you pass your page's `cspNonce`; the user then presses the Continue button. |
| `lifecycle({gatewayUrl, signer, subject, event, scopes?})` | `POST /v1/identity/principals/lifecycle`: `suspend`, `reactivate`, `delete`, `scopes_changed`. |
| `revokeSession({gatewayUrl, signer, subject, sessionId})` | `POST /v1/identity/sessions/{id}/revoke`. |
| `logout({gatewayUrl, signer, subject, principalId})` | `POST /v1/identity/principals/{id}/logout`. |
| `verifyTrustedUser(params, {mcpContextSecret, serverId, issuer, tenantId, applicationId, replayGuard?})` | Verifies `params._meta.dewee.trusted_user` in your MCP server and returns the user. |
| `createAssertion({...signer, purpose, subject, ...})` | The signed assertion itself, for a call you make on your own. |

A `signer` is `{applicationId, issuer, secret}` for an `hmac` application, or
`{applicationId, issuer, privateKeyJwk, algorithm}` (RS256, ES256 or EdDSA, with a `kid`) for a
`jwks` one. The `subject` is your stable user id: at most 255 bytes and never an email address.
The SDK refuses any subject containing `@`, which is stricter than the gateway's email-shape check.

`verifyTrustedUser` accepts each `jti` once. Its default `MemoryReplayGuard` keeps up to 100,000
unexpired ids in process memory and fails closed when full (every new token is refused with reason
`replay` until ids expire). Use it for development or a single process; in production pass a
shared `replayGuard` (Redis `SET NX EX`, a database row with a unique key).

Gateway calls take `gatewayUrl` (https, or http on localhost; `allowInsecureHttp` for a private
network), `timeoutMs` (default 10000), `signal` and `fetch`.

## Errors

Every failure is a `DeweeIdentityError`:

```ts
try {
  await exchangeSession(opts);
} catch (err) {
  if (err instanceof DeweeIdentityError) {
    err.code;              // IDENTITY_REQUIRED, LINK_REVOKED, RESOURCE_EXHAUSTED, TRANSPORT_ERROR, ...
    err.status;            // HTTP status, 0 when no answer arrived
    err.remediation;       // {action, audience} for identity errors
    err.retryAfterSeconds; // set on 429
    err.retryable;         // true for rate limits and unavailable sources
  }
}
```

`verifyTrustedUser` refuses with `IDENTITY_REQUIRED` and a `reason` (`signature`, `audience`,
`issuer`, `tenant`, `application`, `expired`, `replay`, and so on) for your logs. A missing
verification setting is `INVALID_ARGUMENT`: all four bindings (server, issuer, tenant,
application) are required.

## Development

```sh
pnpm --filter @dewee/identity typecheck
pnpm --filter @dewee/identity test             # unit and cross-language fixture tests
pnpm --filter @dewee/identity lint             # build + publint --strict
DEWEE_IT_GATEWAY_URL=http://127.0.0.1:18790 DEWEE_IT_GATEWAY_TOKEN=... \
  pnpm --filter @dewee/identity test:integration   # against a live gateway with an agent "sdk-it"
```

The fixtures in `test/fixtures` are shared with the Go tests: `pnpm --filter @dewee/identity
fixtures:generate` rewrites the SDK-signed assertions that `internal/identity/assertion` verifies,
and `DEWEE_UPDATE_SDK_FIXTURES=1 go test ./internal/identity -run TestSDKTrustedUserFixture`
rewrites the gateway-signed token the SDK verifies. All values in them are test-only.

## License

CC-BY-NC-4.0, as the rest of the repository.
